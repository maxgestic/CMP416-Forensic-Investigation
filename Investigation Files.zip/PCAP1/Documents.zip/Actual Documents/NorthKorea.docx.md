# OG Document Contents
```
0JTQu9GPINC60L7Qs9C+INGN0YLQviDQvNC+0LbQtdGCINC60LDRgdCw0YLRjNGB0Y86IA0KDQrQryDQsdGL0Lsg0YHQstC40LTQtdGC0LXQu9C10LwsINGH0YLQviDQmtC40Lwg0KfQtdC9INCj0L0g0Lgg0L/RgNCw0LLQuNGC0LXQu9GM0YHRgtCy0L4g0KHQtdCy0LXRgNC90L7QuSDQmtC+0YDQtdC4INGA0LDQt9GA0LDQsdC+0YLQsNC70Lgg0L/RgNC+0LPRgNCw0LzQvNGDLCDQutC+0YLQvtGA0LDRjyDQv9C+0LfQstC+0LvRj9C10YIg0LjQvCDQv9GD0YLQtdGI0LXRgdGC0LLQvtCy0LDRgtGMINCy0L4g0LLRgNC10LzQtdC90LguINChINC40YHQv9C+0LvRjNC30L7QstCw0L3QuNC10Lwg0Y3RgtC+0Lkg0YLQtdGF0L3QvtC70L7Qs9C40LgsINGPINGB0YfQuNGC0LDRjiwg0YfRgtC+INC+0L3QuCDQvdCw0LzQtdGA0LXQvdGLINC00LLQuNCz0LDRgtGM0YHRjyDQstC/0LXRgNC10LQg0Lgg0LjQt9C80LXQvdC40YLRjCDRgNC10LfRg9C70YzRgtCw0YLRiyDQstC+0LnQvdGLINCyINCa0L7RgNC10LUuIA0KDQrQn9C+0LbQsNC70YPQudGB0YLQsCwg0J7QsdC4LdCS0LDQvSwg0YLRiyDQvNC+0Y8g0LXQtNC40L3RgdGC0LLQtdC90L3QsNGPINC90LDQtNC10LbQtNCwLg0KDQo=
```

# B64 Decoded
```
Для кого это может касаться: 

Я был свидетелем, что Ким Чен Ун и правительство Северной Кореи разработали программу, которая позволяет им путешествовать во времени. С использованием этой технологии, я считаю, что они намерены двигаться вперед и изменить результаты войны в Корее. 

Пожалуйста, Оби-Ван, ты моя единственная надежда.


```

# Translated from Russian
```
To whom it may concern:

I have witnessed that Kim Jong Un and the North Korean government have developed a program that allows them to travel through time. With this technology, I believe they intend to move forward and change the outcome of the Korean War.

Please, Obi-Wan, you are my only hope.
```