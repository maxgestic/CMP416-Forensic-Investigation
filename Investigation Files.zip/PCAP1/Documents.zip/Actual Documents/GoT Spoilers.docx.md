# Original Document Contents
```
Sm9uIFNub3cgYnVybnMgZG93biBXaW50ZXJmZWxsIChhZ2FpbikgYW5kIHRoZSBXYWxsLg0KDQpIb2RvciBraWxscyBUaGVvbi4NCg0KRGFlbmVyeXMgZ2V0cyBlYXRlbiBieSBhIGRyYWdvbi4NCg0KU3Rhbm5pcyBmYWxscyBpbiBsb3ZlIHdpdGggVHlyaW9uLiANCg0KDQo=
```

# B64 Decoded
```
Jon Snow burns down Winterfell (again) and the Wall.

Hodor kills Theon.

Daenerys gets eaten by a dragon.

Stannis falls in love with Tyrion. 



```

Thank god i dont watch this show...