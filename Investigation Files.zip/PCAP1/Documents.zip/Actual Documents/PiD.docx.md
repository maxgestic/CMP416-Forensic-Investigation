# OG Doc Contents
```
RGVhciBFZCwNCg0KWWVhaCBJIHRvdGFsbHkgdG9vayBvdmVyIGZvciBQYXVsIGFmdGVyIGhlIGRpZWQgaW4g4oCZNjYuIFlvdSBnb3QgbWUuIEFzIHlvdSBjYW4gc2VlLCB3ZSBkb27igJl0IGV2ZW4gbG9vayB0aGF0IG11Y2ggYWxpa2U6DQo=

Before(Paul) After(Me)

IAkgCQ0KQmVmb3JlKFBhdWwpIAkJCQkJQWZ0ZXIoTWUpDQoNCldlIGFyZW7igJl0IGV2ZW4gdGhlIHNhbWUgaGVpZ2h0ISBXaGF0IGNhbiBJIHNheSwgcGVvcGxlIGFyZSBzdHVwaWQuDQoNCg0KVGhhbmtzIGZvciB0aGUgaW5xdWlyeSwNCg0KV2lsbGlhbSBDYW1wYmVsbA0KKFBhdWwgTWNDYXJ0bmV5KQ0K
```

## Two images in document
Before(Paul):
![[Before(Paul).png]]
After(Me):
![[After(Me).png]]

# B64 Decoded
```
Dear Ed,

Yeah I totally took over for Paul after he died in ’66. You got me. As you can see, we don’t even look that much alike:
 	 	
Before(Paul) 					After(Me)

We aren’t even the same height! What can I say, people are stupid.


Thanks for the inquiry,

William Campbell
(Paul McCartney)

```