This was a zip file found in the Documents.zip
It contained the following folder structure:
`/untitled folder/untitled folder/untitled folder 2/untitled folder/untitled folder/SilentEye`
SilentEye is an old Steganography tool that is used to hide text in images
Will try and use SilentEye on both [[NorthKorea.jpeg]], [[NK.jpg]], [[Before(Paul).png]] and [[After(Me).png]]
None of these showed any results, however 