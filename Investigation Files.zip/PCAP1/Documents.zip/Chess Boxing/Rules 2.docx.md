# OG Doc
```
IDIuICAgRU5GT1JDRU1FTlQgT0YgQ0hFU1MgUlVMRVMNCiBJbiB0aGUgZXZlbnQgb2YgYSBicmVhY2ggb2YgdGhlIHJ1bGVzIGEgcGVuYWx0eSBjYW4gYmUgaW1wb3NlZCBhdCB0aGUgYXJiaXRlcuKAmXMgZGlzY3JldGlvbi4NCiANCg0K
```

# B64 Decode
```
 2.   ENFORCEMENT OF CHESS RULES
 In the event of a breach of the rules a penalty can be imposed at the arbiter’s discretion.
 


```
