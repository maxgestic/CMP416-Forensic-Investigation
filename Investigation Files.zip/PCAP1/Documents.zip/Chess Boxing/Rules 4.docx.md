# OG Doc
```
NC4gICBDSEVTUyBDTE9DSyBNQUxGVU5DVElPTg0KSW4gdGhlIHVubGlrZWx5IGV2ZW50IHRoZSBlbGVjdHJvbmljIGNoZXNzIGNsb2NrIGNlYXNlcyB0byBvcGVyYXRlIGR1cmluZyBhIGNoZXNzIHJvdW5kLCB0aGUgYXJiaXRlciB3aWxsIGRvIG9uZSBvZiBmb2xsb3dpbmcsIGRlcGVuZGluZyBvbiB0aGUgZXN0aW1hdGVkIGRpc3J1cHRpb24gdG8gdGhlIHBsYXllcnMgYW5kIHNwZWN0YXRvcnM6DQrigKIJU3RvcCB0aGUgY2xvY2sgYW5kIHJlc29sdmUgdGhlIHByb2JsZW0uDQrigKIJU3RvcCB0aGUgY2xvY2sgYW5kIHJlcGxhY2UgaXQgd2l0aCBhIG5ldyBjbG9jay4gIFRoaXMgYWN0aW9uIGlzIG1vc3QgbGlrZWx5IGlmIHRoZXJlIGlzIGEgcmVwZWF0ZWQgbWFsZnVuY3Rpb24sIG9yIGl04oCZcyBvbmUgb2YgdGhlIGxhdGVyIGNoZXNzIHJvdW5kcyB3aGVyZSBhIHBsYXllciBpcyBzaG9ydCBvZiB0aW1lLg0KDQoNCg==
```

# B64 Decoded
```
4.   CHESS CLOCK MALFUNCTION
In the unlikely event the electronic chess clock ceases to operate during a chess round, the arbiter will do one of following, depending on the estimated disruption to the players and spectators:
•	Stop the clock and resolve the problem.
•	Stop the clock and replace it with a new clock.  This action is most likely if there is a repeated malfunction, or it’s one of the later chess rounds where a player is short of time.



```
