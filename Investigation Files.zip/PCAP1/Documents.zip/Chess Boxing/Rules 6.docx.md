# OG Doc
```
Ni4gICBDSEVTUyBEUkFXIElOIFJFTEFUSU9OIFRPIFRIRSBDSEVTU0JPWElORyBCT1VUDQogDQogSWYgYSBjaGVzcyBkcmF3IGlzIGRlY2xhcmVkIGluIGFueSByb3VuZCwgdGhlcmUgd2lsbCBiZSBhdCBtb3N0IG9ubHkgb25lIGJveGluZyByb3VuZCB0aGVyZWFmdGVyLiAgSWYgdGhlIGNoZXNzIGRyYXcgb2NjdXJzIGluIHRoZSBmaW5hbCByb3VuZCwgdGhlbiB0aGVyZSB3aWxsIGJlIG5vIGZ1cnRoZXIgYm94aW5nIHJvdW5kLCBpbiBsaW5lIHdpdGggdGhlIG9yaWdpbmFsIHNjaGVkdWxlLg0KSW4gdGhlIHVubGlrZWx5IGV2ZW50IHRoYXQgdGhlIGNoZXNzIGdhbWUgaXMgZHJhd24gQU5EIHRoZSBib3hpbmcgaXMgYSB0aWUgb24gcG9pbnRzLCB0aGVuIHRoZSBwbGF5ZXIgd2l0aCB0aGUgZmV3ZXN0IGNoZXNzIHBlbmFsdGllcyBpcyB0aGUgd2lubmVyLiBJZiB0aGVzZSBhcmUgZXF1YWwgdGhlIGJvdXQgd2lsbCBiZSBkZWNsYXJlZCBhIGRyYXcuDQogDQoNCg==
```

# B64 Decoded
```
6.   CHESS DRAW IN RELATION TO THE CHESSBOXING BOUT
 
 If a chess draw is declared in any round, there will be at most only one boxing round thereafter.  If the chess draw occurs in the final round, then there will be no further boxing round, in line with the original schedule.
In the unlikely event that the chess game is drawn AND the boxing is a tie on points, then the player with the fewest chess penalties is the winner. If these are equal the bout will be declared a draw.
 


```
