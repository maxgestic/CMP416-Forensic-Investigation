# OG Doc
```
My4gIFBFTkFMVElFUyBGT1IgUlVMRSBCUkVBQ0hFUw0KQSBjaGVzcyBwZW5hbHR5IGNvdWxkIHRha2UgdGhlIGZvcm0gb2Y6DQrigKIJVGhlIG9mZmVuY2Ugd2lsbCBhY3QgYXMgYSB0aWUtYnJlYWsgaWYgYm90aCB0aGUgYm94aW5nIGFuZCBjaGVzcyBhcmUgZHJhd24uICBUaGlzIGlzIHRoZSBtaW5pbXVtIChkZWZhdWx0KSBwZW5hbHR5IGFuZCBhcHBsaWVzIGlmIHRoZXJlIGlzIG5vIG90aGVyIHBlbmFsdHkuDQrigKIJMzAgc2Vjb25kcyBpcyBzdWJ0cmFjdGVkIGZyb20gdGhlIG9mZmVuZGVy4oCZcyBjbG9jay4NCuKAoglGb3JmZWl0IG9mIHRoZSBib3V0LiBUaGlzIGNvdWxkIG9jY3VyIGZvciBhIHNlcmlvdXMgZGlzY2lwbGluYXJ5IG9mZmVuY2UsIGRlbGliZXJhdGUgZm91bCBwbGF5IG9yIGEgcmVwZWF0ZWQgYnJlYWNoIChlLmcuIGEgdG90YWwgb2YgMyBpbGxlZ2FsIG1vdmVzKS4NCg==
```

# B64 Decoded
```
3.  PENALTIES FOR RULE BREACHES
A chess penalty could take the form of:
•	The offence will act as a tie-break if both the boxing and chess are drawn.  This is the minimum (default) penalty and applies if there is no other penalty.
•	30 seconds is subtracted from the offender’s clock.
•	Forfeit of the bout. This could occur for a serious disciplinary offence, deliberate foul play or a repeated breach (e.g. a total of 3 illegal moves).

```
