# Original Document Content
```
VGhlIE15c3Rlcnkgb2YgQ2hlc3MgQm94aW5nOg0KKHVzZXJuYW1lcykNCg0KTXIuIE1ldGhvZA0KDQpLaW0gSWxsLVNvbmcNCg0KTXIuIFJhem9yDQoNCk1yLiBHZW5pdXMNCg0KTXIuIEcuIEtpbGxhaA0KDQpNYXR0IENhc3NlbA0KDQpNci4gSS4gRGVjaw0KDQpNci4gTSBLaWxsYQ0KDQpNci4gTy5ELkIuDQoNCk1yLiBSYWVrd29uDQoNCk1yLiBVLUdvZA0KDQpNci4gQ2FwcGFkb25uYSAocG9zc2libHkpDQoNCkpvaG4gV29vPw0KDQpNci4gTmFzDQo=
```

# Base64 Decoded
```
The Mystery of Chess Boxing:
(usernames)

Mr. Method

Kim Ill-Song

Mr. Razor

Mr. Genius

Mr. G. Killah

Matt Cassel

Mr. I. Deck

Mr. M Killa

Mr. O.D.B.

Mr. Raekwon

Mr. U-God

Mr. Cappadonna (possibly)

John Woo?

Mr. Nas

```

